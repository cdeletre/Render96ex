const struct Animation *const motos_anims[] = {
	&motos_anim_tpose,
	&motos_anim_motos_mario_carry,
	&motos_anim_motos_carry_run,
	&motos_anim_motos_carry_start,
	&motos_anim_motos_down_recover,
	&motos_anim_tpose,
	&motos_anim_motos_pitch,
	&motos_anim_tpose,
	&motos_anim_tpose,
	&motos_anim_motos_walk,
	NULL,
};

/*
	&motos_basedata_A_anm,
	&motos_carry_anm,
	&motos_carry_run_anm,
	&motos_carry_start_anm,
	&motos_down_recover_anm,
	&motos_down_stop_anm,
	&motos_pitch_anm,
	&motos_safe_down_anm,
	&motos_wait_anm,
	&motos_walk_anm,
*/